import pyspark
sc = pyspark.SparkContext()
data = sc.parallelize(["Hello world","Bye world"])
counts = data.flatMap(lambda line: line.split(" ")).map(lambda word: (word, 1)).countByKey()
print(counts)