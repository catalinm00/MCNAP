#include <stdio.h>
#include <stdlib.h>
#include <sys/times.h>
#include <unistd.h>

// ============================================================================
double d_mono_clock( void );
// Returns the time elapsed in seconds since some moment in the past.
// It employs the dclock_getres/dclock_gettime interface with monotonic time.

//// double etime( void );
//// // Returns the time elapsed since some moment in the past.
//// 
//// double dsecnd( void );
//// // Returns the addition of the user and system time (elapsed since some 
//// // moment in the past) of the current process.

int rnd_uniform_int( int n );
// Generates a integer random number between 0 and n-1.

double rnd_uniform_double( void );
// Generates a double random number between 0.0 and 1.0.

double rnd_uniform_double_between_1and1( void );
// Generates a double random number between -1.0 and 1.0.

void vector_generate( int n, double * x, int seed );
// Generates a vector "x" of doubles by using random generator "r".

void print_vector( char * name, int n, double * x );
// Prints a vector "x" of doubles.

double vector_diff( int n, double * x, double * y );
// Computes || x - y ||_2 / || y ||_2.

void vector_set_to_zero( int n, double * x );
// Sets vector x to zero.

double sum_vector( int n, double * a );

