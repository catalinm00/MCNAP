#include <stdio.h>
#include <stdlib.h>
#include <time.h>
//// #include <sys/times.h>
//// #include <unistd.h>
#include "utils.h"


// ============================================================================
double d_mono_clock( void ) {
// Returns the time elapsed since some moment in the past.
  struct timespec ts;
  double          t;

  //// if( clock_gettime( CLOCK_MONOTONIC_COARSE, & ts ) == -1 ) {
  if( clock_gettime( CLOCK_MONOTONIC_RAW, & ts ) == -1 ) {
    perror( "ERROR in clock_gettime with CLOCK_MONOTONIC.\n" );
    exit( EXIT_FAILURE );
  }
  t = ( ( double ) ts.tv_sec ) + 1.0e-9 * ( ( double ) ts.tv_nsec );

  //// printf( "ts.tv_sec:   %ld\n", ts.tv_sec );
  //// printf( "ts.tv_nsec:  %ld\n", ts.tv_nsec );
  //// printf( "t:           %lf\n", t );

  return t;
}

//// // ============================================================================
//// double etime( void ) {
//// // Returns the time elapsed since some moment in the past.
////   clock_t     ct;
////   struct tms  t;
//// 
////   ct = times( &t );
//// 
////   if ( ct == (clock_t) -1 )
////     return 0.0;
////   else
////     return( ((double) ct) /
////             ((double) sysconf(_SC_CLK_TCK)) );
//// }
//// 
//// // ============================================================================
//// double dsecnd( void ) {
//// // Returns the addition of the user and system time (elapsed since some
//// // moment in the past) of the current process.
////   clock_t     ct;
////   struct tms  t;
//// 
////   ct = times( &t );
//// 
////   if ( ct == (clock_t) -1 )
////     return 0.0;
////   else
////     return( ((double) ( t.tms_utime + t.tms_stime )) /
////             ((double) sysconf( _SC_CLK_TCK )) );
//// }

// ============================================================================
int rnd_uniform_int( int n ) {
// Generates a integer random number between 0 and n-1.
  return rand() % n;
}

// ============================================================================
double rnd_uniform_double( void ) {
// Generates a double random number between 0.0 and 1.0.
  return ( ( double ) rand() ) / ( ( double ) RAND_MAX );
}

// ============================================================================
double rnd_uniform_double_between_1and1( void ) {
// Generates a double random number between -1.0 and 1.0.
  return ( ( double ) rand() ) / ( ( double ) RAND_MAX ) * 2.0 - 1.0;
}

// ============================================================================
void vector_generate( int n, double * x, int seed ) {
// Generates a vector "x" of doubles by using random generator "r".
  int i;
  srand( ( unsigned int ) seed );
  for ( i = 0; i < n; i++ ) {
    x[ i ] = rnd_uniform_double_between_1and1();
  }
}

// ============================================================================
void print_vector( char * name, int n, double * x ) {
// Prints a vector "x" of doubles.
  int i;

  for ( i = 0; i < n; i++ ) {
    printf( "%s( %d ) = %le\n", name, i+1, x[ i ] );
  }
}

// ============================================================================
double vector_diff( int n, double * x, double * y ) {
// Computes || x - y ||_2 / || y ||_2.
  double dif, nrmy;
  int    i;

  dif  = 0.0;
  nrmy = 0.0;
  for( i = 0; i < n; i++ ) {
    dif  += ( x[ i ] - y[ i ] )*( x[ i ] - y[ i ] );
    nrmy += y[ i ]*y[ i ];
  }

  if( nrmy == 0.0 ) {
    return dif;
  } else {
    return dif / nrmy;
  }
}

// ============================================================================
void vector_set_to_zero( int n, double * x ) {
// Sets vector x to zero.
  int i;

  for( i = 0; i < n; i++ ) {
    x[ i ] = 0.0;
  }
}

// ============================================================================
double sum_vector( int n, double * a ) {
// Sum contents of vector a.
  int    i;
  double s = 0.0;
  for( i = 0; i < n; i++ ) {
    s += a[ i ];
  }
  return s;
}

