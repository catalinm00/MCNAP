#include <math.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include "utils.h"




// ============================================================================
// Some macros.

#define max(a,b) ( (a) > (b) ? (a) : (b) )
#define min(a,b) ( (a) < (b) ? (a) : (b) )
#define dabs(a) ( (a) > 0.0 ? (a) : -(a) )


// ============================================================================
// Function prototypes.

int test_read_info( char * filename, int * ndim, int ** mvalues, 
    int ** nvalues, int * nexecs, int * print_data, int * seed );

void print_result( char * name, int m, int n, double time_per_exec,
    double sum );

void polic_ruffini_1( int n, double * a, int m, double * x, double * y );



// ============================================================================
int main( int argc, char *argv[] ) {
  char    * filename;
  int     ndim, idim, * mvalues, * nvalues, m, n,
          nexecs, ne, info, print_data, seed[ 4 ] ;
  double  t1, t2, ttotal, texec;
  double  * a, * x, * y, * ycopy, sum;

  // Checking the number of arguments.
  if ( argc != 2 ) {
    printf( "\nUsage:  %s file.in\n\n", argv[ 0 ] );
    exit( -1 );
  }
  filename = argv[ 1 ];
  //// printf( "Name of file: %s\n", filename );

  // Reading the input arguments.
  info = test_read_info( filename, & ndim, & mvalues, & nvalues, & nexecs, 
                         & print_data, seed );

  if( info != 0 ) {
    printf( "Error in test_read_info\n" );
    exit( -1 );
  }
  
  printf( "%%\n" );
  printf( "%% Method                        m      " );
  printf( "n      t_exec      sum\n" );
  printf( "%% -------------------------------------" );
  printf( "----------------------------------------\n" );
  for ( idim = 0; idim < ndim; idim++ ) {
    m = mvalues[ idim ];
    n = nvalues[ idim ];

    // ======================================================================
    // Create and Generate data: vectors a, x, and y.
    // ======================================================================

    a     = (double *) malloc( (n+1) * sizeof( double ) ); 
    x     = (double *) malloc( m * sizeof( double ) ); 
    y     = (double *) malloc( m * sizeof( double ) ); 
    ycopy = (double *) malloc( m * sizeof( double ) ); 
 
    vector_generate( n + 1, a, seed[ 0 ] );
    vector_generate( m, x, seed[ 1 ] );
    vector_set_to_zero( m, y );
    vector_set_to_zero( m, ycopy );

 
 
    // ====================================================================
    // Timing "ruffini 1".
    // ====================================================================

    // Set to zero result vector.
    vector_set_to_zero( m, y );

    // Print initial data.
    if( print_data == 1 ) {
      print_vector( "aini1", n+1, a );
      printf( "\n" );
      print_vector( "xini1", m, x );
      printf( "\n" );
      print_vector( "yini1", m, y );
      printf( "\n" );
    }
  
    // Time method.
    t1 = d_mono_clock();
    for ( ne = 0; ne < nexecs; ne++ ) {
      polic_ruffini_1( n, a, m, x, y );
    }
    t2 = d_mono_clock();
    ttotal = t2 - t1;
    texec = ttotal / ( ( double ) nexecs );

    // Print final data.
    if( print_data == 1 ) {
      print_vector( "afin1", n+1, a );
      printf( "\n" );
      print_vector( "xfin1", m, x );
      printf( "\n" );
      print_vector( "yfin1", m, y );
      printf( "\n" );
    }

    sum = sum_vector( m, y );
    // Print results.
    print_result( "Ruffini 1", m, n, texec, sum );
 


 
    printf( "%% -------------------------------------" );
    printf( "----------------------------------------\n" );

    // Remove data vectors.
    free( a );
    free( x );
    free( y );
    free( ycopy );
  }

  // Remove dynamic vectors.
  free( mvalues );
  free( nvalues );

  printf( "%% End of Program\n" );
  printf( "\n" );
}

// ============================================================================
int test_read_info( char * filename, int * ndim, int ** mvalues, 
    int ** nvalues, int * nexecs, int * print_data, int * seed ) {
//
  const int MAX_LINE_LENGTH = 1024;
  FILE  * fp;
  char  myLine[ MAX_LINE_LENGTH ];
  int   i, rv;
  char  * rv_pc;

  printf( "\n" );

  // Open the file.
  if ( ( fp = fopen( filename, "r" ) ) == NULL )
    return -1;

  // Reading number of dimensions to test.
  rv = fscanf( fp, "%d", ndim );
  rv_pc = fgets( myLine, MAX_LINE_LENGTH, fp );
  if( * ndim == 0 ) {
    printf( "ERROR: Number of dimensions is zero.\n" ); 
    return (-1);
  }
  printf( "%% Test %d dimensions:\n", * ndim );

  // Creating the vectors to hold the dimensions.
  *mvalues = (int *) malloc( *ndim * sizeof( int ) );
  *nvalues = (int *) malloc( *ndim * sizeof( int ) );

  // Reading the dimensions "m".
  for( i = 0; i < * ndim; i++ )
    rv = fscanf( fp, "%d", (*mvalues+i) );
  rv_pc = fgets( myLine, MAX_LINE_LENGTH, fp );

  // Write the dimensions.
  printf( "%%   Number of points:  " );
  for( i = 0; i < * ndim; i++ )
    printf( "%7d ", *(*mvalues+i) );
  printf( "\n" );

  // Reading the dimensions "n".
  for( i = 0; i < * ndim; i++ )
    rv = fscanf( fp, "%d", (*nvalues+i) );
  rv_pc = fgets( myLine, MAX_LINE_LENGTH, fp );

  // Write the dimensions.
  printf( "%%   Polynomial order:  " );
  for( i = 0; i < * ndim; i++ )
    printf( "%7d ", *(*nvalues+i) );
  printf( "\n" );


  // Reading the number of executions.
  rv = fscanf (fp, "%d", nexecs );
  rv_pc = fgets( myLine, MAX_LINE_LENGTH, fp );
  printf( "%% Number of executions:         %d\n", * nexecs );

  // Reading whether print data.
  rv = fscanf( fp, "%d", print_data );
  rv_pc = fgets( myLine, MAX_LINE_LENGTH, fp );
  printf( "%% Print data (0=no;1=yes):      %d\n", * print_data );

  // Reading seeds. Last value must be odd.
  rv = fscanf( fp, "%d", seed );
  rv = fscanf( fp, "%d", seed+1 );
  rv = fscanf( fp, "%d", seed+2 );
  rv = fscanf( fp, "%d", seed+3 );
  rv_pc = fgets( myLine, MAX_LINE_LENGTH, fp );
  if( *( seed+3 ) % 2 == 0 ) {
    printf( "ERROR: Last value of seeds must be odd.\n" ); 
    return (-1);
  }
  printf( "%% Seeds:                        %d %d %d %d\n",
          *seed, *(seed+1), *(seed+2), *(seed+3) );

  // Close the file.
  fclose( fp );

  return 0;
}

// ============================================================================
void print_result( char * name, int m, int n, double time_per_exec,
    double sum ) {
// Print results.
  printf( "%-27s  %7d %5d  %11.4le  %15.8le\n", name, m, n, time_per_exec, 
          sum );
  fflush( stdout );
}

// ============================================================================
void polic_ruffini_1( int n, double * a, int m, double * x, double * y ) {
  int i, j;

  for( i = 0; i < m; i++ ) {
    // Evaluate i-th point.
    y[ i ] = 0.0;
    for( j = n; j >= 0; j-- ) {
      // Evaluate j-th term.
      y[ i ] = y[ i ] * x[ i ] + a[ j ];
    }
  }
}

