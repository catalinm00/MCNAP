===============================================================================
README.txt
===============================================================================

This directory is associated to the assignment la01.
Read it in order to know what to do.

You can send any questions on this to the following email:
  gquintan@uji.es

