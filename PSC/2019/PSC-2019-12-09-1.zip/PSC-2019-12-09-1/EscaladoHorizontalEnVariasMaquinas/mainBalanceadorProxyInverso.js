
// -------------------------------------------------------------- 
// -------------------------------------------------------------- 
var http = require('http');
var httpProxy = require('http-proxy');

// -------------------------------------------------------------- 
// -------------------------------------------------------------- 
function main() {

	// 
	// direcciones de los listaWorkers
	// (para verdaderamente horizontal: arrancar en otras máquinas)
	//
	var listaWorkers = [
		{
			host: '127.0.0.1',
			port: 8081
		},
		{
			host: '127.0.0.1',
			port: 8082
		}
	];

	//
	// creamos el proxy
	//
	var proxy = httpProxy.createServer();

	//
	// servidor http "normal": aquí llegan
	// las peticiones, y desde aquí
	// las enviamos a un worker
	// 
	http.createServer(function (req, res) {

		//
		// balanceador: estrategia simple round-robin
		// 
		// cuando  llega una peticion, cogemos el primer worker
		//
		var target = { target: listaWorkers.shift() };

		//
		//  y le enviamos la petición
		//
		console.log('enviando petición a: ', target);
		proxy.web(req, res, target);

		//
		// luego ponemos el worker al final de la lista
		//
		listaWorkers.push(target.target);

	}).listen(8080);
} // ()

// -------------------------------------------------------------- 
// -------------------------------------------------------------- 
main()

// -------------------------------------------------------------- 
// -------------------------------------------------------------- 
// -------------------------------------------------------------- 
// -------------------------------------------------------------- 
