
# arrancar workers
node mainServidorWorker.js 8081 &
node mainServidorWorker.js 8082 &

# arrancar balanceador
node mainBalanceadorProxyInverso.js &

sleep 4

# probar que responden, pidiendo directamente
curl http://127.0.0.1:8081
curl http://127.0.0.1:8082


# ahora: pedir al proxy-balanceador

curl http://127.0.0.1:8080
curl http://127.0.0.1:8080
curl http://127.0.0.1:8080
curl http://127.0.0.1:8080
