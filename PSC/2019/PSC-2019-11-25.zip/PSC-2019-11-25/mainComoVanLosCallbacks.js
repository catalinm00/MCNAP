
// ------------------------------------------
// Ejemplo1.js
// ------------------------------------------

// ------------------------------------------
// R -> porDos() -> R
// ------------------------------------------
function porDos( a ) {
	return a*2
} // ()

// ------------------------------------------
// R -> porDos() -> R
//
// físicament recibe en a el valor que hay que
// multiplicar por 2
// y recibe en f a la función a la que hay
// que llamar para dar el resultado
// ------------------------------------------
function porDosBis( a, f ) {
	f( a*2 ) // = return a*2
} // ()

// ------------------------------------------
// R -> porDos() -> R
// 
// deja el reultado en la casilla 0 de
// un array
// ------------------------------------------
function porDosTris( a, p ) {
	p[0] = a*2
} // ()

// ------------------------------------------
// ------------------------------------------
function main () {
	console.log( "hola que tal" )

	var r = porDos( 15 )

	console.log( " r = " + r )

	// llama a la función porDosBis()
	// para calcular el doble de 15
	porDosBis( 15, function( resultado ) {
		console.log( " resultado = " + resultado )
	})

	// 
	console.log( " porDosTris() " ) 
	var lista = [11, 22, 33]
	porDosTris( 15, lista )
	console.log( lista[0] )
	console.log( lista[1] )
} // main()

// ------------------------------------------
// ------------------------------------------
main()
// ------------------------------------------
// ------------------------------------------
