

node mainCliente.js AAAA &
node mainCliente.js BBBB &
