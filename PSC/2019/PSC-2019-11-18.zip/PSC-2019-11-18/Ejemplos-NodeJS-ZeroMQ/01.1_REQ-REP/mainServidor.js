
// ....................................................
var zmq = require('zeromq')

// ....................................................
var socketResponse = zmq.socket('rep')

// ....................................................
var cont = 0

// ....................................................
socketResponse.on('message', function(request) {

	cont++

	console.log("servidor recibo petición: " + cont + " [", request.toString(), "]")

	setTimeout(
		function() {
		
			// respondemos
			console.log("servidor respondo petición: " + cont )
			if (socketResponse) 
				socketResponse.send(" respuesta desde servidor, echo de " + request.toString())
		}, 4000)
})

// ....................................................
socketResponse.bind('tcp://*:5555', function(err) {
	if (err) {
		console.log(err)
	} else {
		console.log("Listening on 5555...")
	}
})

// ....................................................
process.on('SIGINT', function() {
	console.log (" sigint capturada ! ")
	socketResponse.close()
	socketResponse = null
})
