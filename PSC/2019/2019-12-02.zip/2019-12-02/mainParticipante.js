
// ---------------------------------------------------------
// ---------------------------------------------------------
var zmq = require('zeromq')

// ---------------------------------------------------------
// ---------------------------------------------------------
class LectorTeclado {

	// .....................................................
	// ( Texto -> () ) -> constructor() ->
	// .....................................................
	constructor( textoHaSidoLeido ) {

		var stdin = process.openStdin()

		stdin.addListener ("data", 
						   function (datos) {
							   textoHaSidoLeido( datos.toString() ) 
						   }
						  );
	} // ()
} // class

// ---------------------------------------------------------
// ---------------------------------------------------------
class Chat {

	// .....................................................
	// URL, URL, Texto, Texto,
	// ( Texto, Texto, Texto -> () )  -> constructor() ->
	// .....................................................
	constructor( urlEnviar, urlRecibir,
				 nick, canal, funcionNuevoMensaje ) {
		
		//
		//
		//
		this.nick = nick
		this.canal = canal

		//
		//
		//
		this.emisor = zmq.socket('req')
		this.emisor.on( "message", function( resp ) {
			// resp debe ser OK
			// console.log( resp.toString() )
		} )

		this.emisor.connect( urlEnviar )

		//
		//
		//
		var receptor = zmq.socket('sub')

		receptor.on("message", function() {
			var respuesta = Array.from ( arguments )
			var canal = respuesta[0];
			var nick = respuesta[1];
			var texto = respuesta[2];
			funcionNuevoMensaje( canal, nick, texto )
		} )
		
		receptor.connect( urlRecibir )
		receptor.subscribe( canal )
		
		//
		//
		//
		process.on('SIGINT', () => {
			console.log( " cerrando " )
			this.emisor.close()
			receptor.close()
			process.exit( 0 )
		})
		
		//
		//
		//
		this.difundirMensaje( "Hola a todos" )
	} // ()

	// .....................................................
	// Texto -> difundirMensaje() ->
	// .....................................................
	difundirMensaje( mensaje ) {
		console.log( " " )
		this.emisor.send( [ this.canal, this.nick, mensaje ] )
	} // ()
} // class

// ---------------------------------------------------------
// ---------------------------------------------------------
function main() {

	var NICK = (process.argv[2] ? process.argv[2]  : "noname")

	var CANAL = (process.argv[3] ? process.argv[3]  : "general")

	var chat = new Chat( "tcp://localhost:8000",
						 "tcp://localhost:8001",
						 CANAL,
						 NICK,
						 function( nick, canal, mensaje ) {
							 console.log( " (" + canal + ") " + nick + " dice: "
										  + mensaje )
						 })

	var lt = new LectorTeclado( function( leido ) {
		// console.log( " > " + leido )
		chat.difundirMensaje( leido )
	} )
	
} // ()

// ---------------------------------------------------------
// ---------------------------------------------------------
main()
// ---------------------------------------------------------
// ---------------------------------------------------------
