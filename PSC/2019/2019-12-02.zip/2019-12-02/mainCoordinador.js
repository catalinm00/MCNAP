
// ---------------------------------------------------------
// ---------------------------------------------------------
var zmq = require('zeromq')

// ---------------------------------------------------------
// ---------------------------------------------------------
class Chat {

	// .....................................................
	// Texto, Texto -> constructor() ->
	// .....................................................
	constructor( urlReceptor, urlEmisor ) {

		//
		//
		//
		var self = this

		//
		//
		//
		this.emisor = zmq.socket('pub')
		this.emisor.bind( urlEmisor,
			  function(err) {
				  if (err) { console.log(err) } 
				  else { console.log("Listening on " + urlEmisor) }
			  })


		//
		//
		//
		var receptor = zmq.socket('rep')
		receptor.on("message", 
					function() {
						var peticion = Array.from( arguments )
						var canal = peticion[0]
						var nick = peticion[1]
						var texto = peticion[2]
						console.log( " + " )

						self.difundirMensaje( canal, nick, texto )

						// respondo al participante
						receptor.send ("OK")
					} )

		receptor.bind( urlReceptor,
					   function(err) {
						   if (err) { console.log(err) } 
						   else { console.log("Listening on " + urlReceptor) }
					   })
		//
		//
		//
		process.on('SIGINT', function() {
			console.log( " cerrando " )
			receptor.close()
			self.emisor.close()
			process.exit( 0 )
		})
	} // ()

	// .....................................................
	// Texto, Texto, Texto -> difundirMensaje() ->
	// .....................................................
	difundirMensaje( canal, nick, mensaje ) {
		this.emisor.send( [ canal, nick, mensaje ] )
	} // ()
} // class

// ---------------------------------------------------------
// ---------------------------------------------------------
function main () {
	var chat = new Chat( 'tcp://*:8000', 'tcp://*:8001' )
}  // ()

// ---------------------------------------------------------
// ---------------------------------------------------------
main()
// ---------------------------------------------------------
// ---------------------------------------------------------


