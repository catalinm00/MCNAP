package app;

import org.json.JSONObject;

import components.mqtt.ClienteMqtt;
import utils.MySimpleLogger;

public class PublisherApp {
    public static void main(String[] args) throws Exception {

        MySimpleLogger.level = MySimpleLogger.DEBUG;

        String clientId = args[0];
        ClienteMqtt cliente = new ClienteMqtt();

        String broker = "";
        cliente.connect(broker);

        String topic = "";
        JSONObject msg = new JSONObject();
        msg.put("steps", 100);
        cliente.publish();
        cliente.disconnect();

    }
}
