package app;

import components.mqtt.ClienteMqtt;
import components.mqtt.Subscriber;
import utils.MySimpleLogger;

public class SubscriberApp {

    public static void main(String[] args) throws Exception {

        MySimpleLogger.level = MySimpleLogger.DEBUG;

        String clientId = args[0];
        ClienteMqtt cliente = new ClienteMqtt();

        String broker = "";
        cliente.connect();

        String topic = "";
        Subscriber subscriber = new Subscriber();

        cliente.subscribe();

    }

    
}
