package iap.rest.todolist.decorator;

import java.util.Collection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import iap.ToDoList.EntradaLlista;
import iap.ToDoList.Llista;
import iap.rest.todolist.app.RESTToDoListApplication;

public final class LlistaRESTDecorator {
	
	public static String getRESTURI(String llistaID) {
		return RESTToDoListApplication.ROOT + "/" + RESTToDoListApplication.LLISTA + "/" + llistaID;
	}
	
	public static JSONObject getAsJSON(Llista ll) {
		
		JSONObject llJSON = new JSONObject();
		try {
			llJSON.put("id", ll.getID());
			llJSON.put("nom", ll.getNom());
			llJSON.put("link", getRESTURI(ll.getID()));
			llJSON.put("parentLink", ToDoListRESTDecorator.getRESTURI());
			JSONArray entrades = new JSONArray();
			Collection<EntradaLlista> ellList = ll.getEntrades();
			for ( EntradaLlista ell: ellList )
				entrades.put(EntradaLlistaRESTDecorator.getAsJSON(ell));
			llJSON.put("entrades", entrades);

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return llJSON;
		
	}

	public static JSONObject getHEADAsJSON(Llista ll) {
		
		JSONObject llJSON = new JSONObject();
		try {
			llJSON.put("id", ll.getID());
			llJSON.put("nom", ll.getNom());
			llJSON.put("link", getRESTURI(ll.getID()));
			llJSON.put("parentLink", ToDoListRESTDecorator.getRESTURI());

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return llJSON;
		
	}

	
	
	public static String getAsJSONText(Llista ll) {
		return getAsJSON(ll).toString();
	}
	

	public static String getAsXMLDocument(Llista ll) {
		
		StringBuilder xml = new StringBuilder();
		xml.append("<?xml version=\"1.0\"?>");
		xml.append(getAsXMLElement(ll));
		return xml.toString();
	}
	
	public static String getAsXMLElement(Llista ll) {
		StringBuilder xml = new StringBuilder();
		xml.append("<" + RESTToDoListApplication.LLISTA + ">");
		xml.append("<id>" + ll.getID() + "</id>");
		xml.append("<nom>" + ll.getNom() + "</nom>");
		xml.append("<link>" + getRESTURI(ll.getID()) + "</link>");
		xml.append("<parentLink>" + ToDoListRESTDecorator.getRESTURI() + "</parentLink>");

		StringBuilder xmlSub = new StringBuilder();
		for(EntradaLlista ell:ll.getEntrades())
			xmlSub.append(EntradaLlistaRESTDecorator.getAsXMLElement(ell));
		if ( xmlSub.length() > 0 ) {
			xml.append("<entrades>");
			xml.append(xmlSub);
			xml.append("</entrades>");
		}
		xml.append("</" + RESTToDoListApplication.LLISTA + ">");
		return xml.toString();
	}
	
	public static String getHEADAsXMLElement(Llista ll) {
		StringBuilder xml = new StringBuilder();
		xml.append("<" + RESTToDoListApplication.LLISTA + ">");
		xml.append("<id>" + ll.getID() + "</id>");
		xml.append("<nom>" + ll.getNom() + "</nom>");
		xml.append("<link>" + getRESTURI(ll.getID()) + "</link>");
		xml.append("<parentLink>" + ToDoListRESTDecorator.getRESTURI() + "</parentLink>");
		xml.append("</" + RESTToDoListApplication.LLISTA + ">");
		return xml.toString();
	}
	

}
