package iap.rest.todolist.decorator;

import org.json.JSONException;
import org.json.JSONObject;

import iap.ToDoList.EntradaLlista;
import iap.rest.todolist.app.RESTToDoListApplication;

public final class EntradaLlistaRESTDecorator {
	
	public static String getRESTURI(String llistaID, String entradaID) {
		return RESTToDoListApplication.ROOT + "/" + RESTToDoListApplication.LLISTA + "/"+llistaID+"/" + RESTToDoListApplication.ENTRADA + "/"+entradaID;
	}
	
	public static JSONObject getAsJSON(EntradaLlista ell) {
		
		JSONObject ellJSON = new JSONObject();
		try {
			ellJSON.put("id", ell.getID());
			ellJSON.put("text", ell.getText());
			ellJSON.put("link", getRESTURI(ell.getLlista(), ell.getID()));
			ellJSON.put("parentLink", LlistaRESTDecorator.getRESTURI(ell.getLlista()));
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ellJSON;
		
	}
	
	public static String getAsJSONText(EntradaLlista ell) {
		return getAsJSON(ell).toString();
	}
	
	
	
	public static String getAsXMLDocument(EntradaLlista ell) {
		
		StringBuilder xml = new StringBuilder();
		xml.append("<?xml version=\"1.0\"?>");
		xml.append(getAsXMLElement(ell));
		return xml.toString();
	}
	
	public static String getAsXMLElement(EntradaLlista ell) {
		StringBuilder xml = new StringBuilder();
		xml.append("<" + RESTToDoListApplication.ENTRADA + ">");
		xml.append("<id>"+ell.getID()+"</id>");
		xml.append("<text>"+ell.getText()+"</text>");
		xml.append("<link>" + getRESTURI(ell.getLlista(), ell.getID()) +"</link>");
		xml.append("<parentLink>" + LlistaRESTDecorator.getRESTURI(ell.getLlista()) +"</parentLink>");
		xml.append("</" + RESTToDoListApplication.ENTRADA + ">");
		return xml.toString();
	}


}
