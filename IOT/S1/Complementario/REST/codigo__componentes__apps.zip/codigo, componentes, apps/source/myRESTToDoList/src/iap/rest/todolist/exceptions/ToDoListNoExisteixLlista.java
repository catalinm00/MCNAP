package iap.rest.todolist.exceptions;

public class ToDoListNoExisteixLlista extends Exception {
	private static final long serialVersionUID = 0;

}
