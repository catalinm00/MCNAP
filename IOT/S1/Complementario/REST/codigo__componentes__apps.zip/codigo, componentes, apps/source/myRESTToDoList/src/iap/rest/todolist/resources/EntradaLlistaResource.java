package iap.rest.todolist.resources;

import iap.ToDoList.EntradaLlista;
import iap.ToDoList.Llista;
import iap.ToDoList.ToDoList;
import iap.rest.todolist.app.RESTToDoListApplication;
import iap.rest.todolist.decorator.EntradaLlistaRESTDecorator;
import iap.rest.todolist.exceptions.ToDoListNoExisteixEntradaLlista;
import iap.rest.todolist.exceptions.ToDoListNoExisteixLlista;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.json.JSONException;
import org.json.JSONObject;
import org.restlet.data.MediaType;
import org.restlet.data.Method;
import org.restlet.data.Status;
import org.restlet.representation.Representation;
import org.restlet.representation.StringRepresentation;
import org.restlet.resource.Options;
import org.restlet.resource.Delete;
import org.restlet.resource.Get;
import org.restlet.resource.Put;
import org.restlet.resource.ServerResource;


public class EntradaLlistaResource extends ServerResource {

	protected ToDoList getToDoList() {
		return ((RESTToDoListApplication) this.getApplication()).getToDoList();
	}
	
	protected String getLlistaID() {
		return (String) getRequest().getAttributes().get("LLISTA");
	}
	
	protected String getEntradaID() {
		return (String) getRequest().getAttributes().get("ID");
	}
	
	protected EntradaLlista getEntradaLlista() throws ToDoListNoExisteixLlista, ToDoListNoExisteixEntradaLlista {
    	String llista = this.getLlistaID();
    	String id = this.getEntradaID();
    	Llista ll = this.getToDoList().getLlista(llista);
    	if ( ll == null ) 
    		throw new ToDoListNoExisteixLlista();
    	EntradaLlista ell = ll.getEntrada(id);
    	if ( ell == null )
    		throw new ToDoListNoExisteixEntradaLlista();
    	return ell;
	}

	
	
    @Get("json")
    public Representation getEntradaLlistaJSON() {
    	
    	EntradaLlista ell = null;
		try {
			ell = this.getEntradaLlista();
		} catch (ToDoListNoExisteixEntradaLlista e) {
			setStatus(Status.CLIENT_ERROR_NOT_FOUND);
	        return new StringRepresentation("Entrada Llista no trobada!", MediaType.TEXT_PLAIN);
    	} catch (ToDoListNoExisteixLlista e) {
	        setStatus(Status.CLIENT_ERROR_NOT_FOUND);
	        return new StringRepresentation("Llista no trobada!", MediaType.TEXT_PLAIN);
    	}
    	
    	JSONObject json = EntradaLlistaRESTDecorator.getAsJSON(ell);

    	Representation representation = new StringRepresentation(json.toString(), MediaType.APPLICATION_JSON);
        return representation;
    }
    
    
    
	@Get("xml")
    public Representation getEntradaLlistaXML() {

    	EntradaLlista ell = null;
		try {
			ell = this.getEntradaLlista();
		} catch (ToDoListNoExisteixEntradaLlista e) {
			setStatus(Status.CLIENT_ERROR_NOT_FOUND);
	        return new StringRepresentation("Entrada Llista no trobada!", MediaType.TEXT_PLAIN);
    	} catch (ToDoListNoExisteixLlista e) {
	        setStatus(Status.CLIENT_ERROR_NOT_FOUND);
	        return new StringRepresentation("Llista no trobada!", MediaType.TEXT_PLAIN);
    	}

    	Representation representation = new StringRepresentation(
    			EntradaLlistaRESTDecorator.getAsXMLDocument(ell),
    			MediaType.APPLICATION_XML);
        return representation;
    }
	
	
	
	
	
	@Put("json")
    public Representation updateEntradaLlista(Representation entity) {
		
    	EntradaLlista ell = null;
		try {
			ell = this.getEntradaLlista();
		} catch (ToDoListNoExisteixEntradaLlista e) {
			setStatus(Status.CLIENT_ERROR_NOT_FOUND);
	        return new StringRepresentation("Entrada Llista no trobada!", MediaType.TEXT_PLAIN);
    	} catch (ToDoListNoExisteixLlista e) {
	        setStatus(Status.CLIENT_ERROR_NOT_FOUND);
	        return new StringRepresentation("Llista no trobada!", MediaType.TEXT_PLAIN);
    	}
		
		// JSON input
		JSONObject json = null;
		String newText = null;
		try {
			json = new JSONObject(entity.getText());
			newText = json.getString("text");
		} catch (JSONException e) {
			setStatus(Status.CLIENT_ERROR_UNPROCESSABLE_ENTITY);
			return new StringRepresentation("JSON format error!", MediaType.TEXT_PLAIN);
		} catch (IOException e) {
			setStatus(Status.CLIENT_ERROR_UNPROCESSABLE_ENTITY);
			return new StringRepresentation("JSON format error!", MediaType.TEXT_PLAIN);
		}
		
		ell.updateText(newText);
		
		return new StringRepresentation(EntradaLlistaRESTDecorator.getAsJSONText(ell), MediaType.APPLICATION_JSON);
    }
	
	

    @Delete
    public Representation deleteEntradaLlista() {

    	String llista = this.getLlistaID();
    	String id = this.getEntradaID();

    	Llista ll = this.getToDoList().getLlista(llista);
    	if ( ll == null ) {
			setStatus(Status.CLIENT_ERROR_NOT_FOUND);
	        return new StringRepresentation("Entrada Llista no trobada!", MediaType.TEXT_PLAIN);
    	}
    	
    	ll.removeEntrada(id);
        setStatus(Status.SUCCESS_NO_CONTENT);
        return new StringRepresentation("Ok!", MediaType.TEXT_PLAIN);
    }

    
	
    
    @Options
    public void describe() {
    	Set<Method> meths = new HashSet<Method>();
    	meths.add(Method.GET);
    	meths.add(Method.PUT);
    	meths.add(Method.DELETE);
    	meths.add(Method.HEAD);
    	meths.add(Method.OPTIONS);
		this.getResponse().setAllowedMethods(meths);
    }

}
