package iap.rest.todolist.exceptions;

public class ToDoListNoExisteixEntradaLlista extends Exception {
	private static final long serialVersionUID = 0;

}
