package iap.rest.todolist.decorator;

import iap.ToDoList.Llista;
import iap.ToDoList.ToDoList;
import iap.rest.todolist.app.RESTToDoListApplication;

import java.util.Collection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class ToDoListRESTDecorator {

	public static String getRESTURI() {
		return RESTToDoListApplication.ROOT + "/"
				+ RESTToDoListApplication.LLISTES;
	}

	public static JSONArray getAsJSON(ToDoList tdl) {
		JSONArray todoListJSON = new JSONArray();
		JSONObject jsontdl = new JSONObject();

		try {
			jsontdl.put("link", "/llistes");
		} catch (JSONException e) {
			e.printStackTrace();
		}
		todoListJSON.put(jsontdl);

		Collection<Llista> llistes = tdl.getLlistes();
		for (Llista ll : llistes)
			todoListJSON.put(LlistaRESTDecorator.getHEADAsJSON(ll));
		return todoListJSON;

	}

	public static String getAsJSONText(ToDoList tdl) {
		return getAsJSON(tdl).toString();
	}

	public static String getAsXMLDocument(ToDoList tdl) {

		StringBuilder xml = new StringBuilder();
		xml.append("<?xml version=\"1.0\"?>");
		xml.append(getAsXMLElement(tdl));
		return xml.toString();
	}

	public static String getAsXMLElement(ToDoList tdl) {
		StringBuilder xml = new StringBuilder();
		xml.append("<" + RESTToDoListApplication.LLISTES + ">");
		xml.append("<link>/llistes</link>");
		for (Llista ll : tdl.getLlistes())
			xml.append(LlistaRESTDecorator.getHEADAsXMLElement(ll));
		xml.append("</" + RESTToDoListApplication.LLISTES + ">");
		return xml.toString();
	}

}
