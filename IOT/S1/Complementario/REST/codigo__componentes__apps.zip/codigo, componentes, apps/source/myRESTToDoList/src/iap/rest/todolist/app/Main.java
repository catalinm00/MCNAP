package iap.rest.todolist.app;

import iap.ToDoList.Llista;
import iap.ToDoList.ToDoList;

import org.restlet.Application;
import org.restlet.Component;
import org.restlet.data.Protocol;

public class Main {

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		// Create a new Component.
		Component component = new Component();

		// Add a new HTTP server listening on port 8182.
		component.getServers().add(Protocol.HTTP, 8182);

		ToDoList tdl = new ToDoList();
		Llista ll = tdl.addLlista("conceptos");
		ll.addEntrada("ur", "uris");
		ll.addEntrada("ad", "direccionabilidad");
		ll.addEntrada("ln", "enlaces");
		ll.addEntrada("re", "representaciones");
		ll.addEntrada("iu", "la interfaz uniforme");

		ll = tdl.addLlista("implementaciones");
		ll.addEntrada("re", "restlet");
		ll.addEntrada("dj", "django");
		ll.addEntrada("jax", "jax-rs");
		ll.addEntrada("rr", "ruby on rails");

		// Attach the ToDoList application.
		Application app = new RESTToDoListApplication(tdl);

		component.getDefaultHost().attach(RESTToDoListApplication.ROOT, app);

		// Start the component.
		component.start();
	}

}
