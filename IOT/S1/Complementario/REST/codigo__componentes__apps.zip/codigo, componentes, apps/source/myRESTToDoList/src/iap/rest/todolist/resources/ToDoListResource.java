package iap.rest.todolist.resources;

import iap.ToDoList.Llista;
import iap.ToDoList.ToDoList;
import iap.rest.todolist.app.RESTToDoListApplication;
import iap.rest.todolist.decorator.LlistaRESTDecorator;
import iap.rest.todolist.decorator.ToDoListRESTDecorator;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.json.JSONException;
import org.json.JSONObject;
import org.restlet.data.MediaType;
import org.restlet.data.Method;
import org.restlet.data.Status;
import org.restlet.representation.Representation;
import org.restlet.representation.StringRepresentation;
import org.restlet.resource.Delete;
import org.restlet.resource.Get;
import org.restlet.resource.Options;
import org.restlet.resource.Post;
import org.restlet.resource.ServerResource;

public class ToDoListResource extends ServerResource {

	protected ToDoList getToDoList() {
		return ((RESTToDoListApplication) this.getApplication()).getToDoList();
	}

	@Get("json")
	public Representation getLlistesJSON() throws JSONException {
		return new StringRepresentation(
				ToDoListRESTDecorator.getAsJSONText(this.getToDoList()),
				MediaType.APPLICATION_JSON);
	}

	@Get("xml")
	public Representation getLlistesXML() {
		Representation representation = new StringRepresentation(
				ToDoListRESTDecorator.getAsXMLDocument(this.getToDoList()),
				MediaType.APPLICATION_XML);
		return representation;
	}

	@Post
	public Representation postLlista(Representation entity) {
		return this.postLlistaReturnJSON(entity);
	}

	@Post("json")
	public Representation postLlistaReturnJSON(Representation entity) {

		// JSON input
		JSONObject json = null;
		String newNom = null;
		try {
			json = new JSONObject(entity.getText());
			newNom = json.getString("nom");
			if (newNom == null || newNom.equalsIgnoreCase("")) {
				setStatus(Status.SUCCESS_NO_CONTENT);
				return new StringRepresentation("", MediaType.TEXT_PLAIN);
			}
		} catch (JSONException e) {
			setStatus(Status.CLIENT_ERROR_UNPROCESSABLE_ENTITY);
			return new StringRepresentation("JSON format error!",
					MediaType.TEXT_PLAIN);
		} catch (IOException e) {
			setStatus(Status.CLIENT_ERROR_UNPROCESSABLE_ENTITY);
			return new StringRepresentation("JSON format error!",
					MediaType.TEXT_PLAIN);
		}

		Llista ll = this.getToDoList().addLlista(newNom);

		Representation representation = new StringRepresentation(
				LlistaRESTDecorator.getAsJSONText(ll),
				MediaType.APPLICATION_JSON);

		return representation;
	}

	@Delete
	public Representation deleteToDoList() {

		ToDoList tdl = this.getToDoList();
		tdl.remove();

		setStatus(Status.SUCCESS_NO_CONTENT);
		return new StringRepresentation("Ok!", MediaType.TEXT_PLAIN);
	}

	@Options
	public void describe() {
		Set<Method> meths = new HashSet<Method>();
		meths.add(Method.GET);
		meths.add(Method.DELETE);
		meths.add(Method.HEAD);
		meths.add(Method.OPTIONS);
		this.getResponse().setAllowedMethods(meths);
	}

}
