package iap.rest.todolist.app;

import iap.ToDoList.ToDoList;
import iap.rest.todolist.resources.EntradaLlistaResource;
import iap.rest.todolist.resources.LlistaResource;
import iap.rest.todolist.resources.ToDoListResource;

import org.restlet.Application;
import org.restlet.Restlet;
import org.restlet.routing.Router;

public class RESTToDoListApplication extends Application {

	protected ToDoList list = null;

	public final static String ROOT = "";
	public final static String LLISTES = "llistes";
	public final static String LLISTA = "llista";
	public final static String ENTRADA = "entrada";

	public RESTToDoListApplication(ToDoList list) {
		this.list = list;
	}

	public ToDoList getToDoList() {
		return this.list;
	}

	@Override
	public Restlet createInboundRoot() {

		Router router = new Router(getContext());

		// Define routers for users
		router.attach("/llistes", ToDoListResource.class);
		router.attach("/" + RESTToDoListApplication.LLISTA + "/{LLISTA}",
				LlistaResource.class);
		router.attach("/" + RESTToDoListApplication.LLISTA + "/{LLISTA}/"
				+ RESTToDoListApplication.ENTRADA + "/{ID}",
				EntradaLlistaResource.class);

		return router;
	}

}
