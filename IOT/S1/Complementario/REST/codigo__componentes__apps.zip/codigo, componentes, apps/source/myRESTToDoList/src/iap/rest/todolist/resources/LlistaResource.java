package iap.rest.todolist.resources;

import iap.ToDoList.EntradaLlista;
import iap.ToDoList.Llista;
import iap.ToDoList.ToDoList;
import iap.rest.todolist.app.RESTToDoListApplication;
import iap.rest.todolist.decorator.EntradaLlistaRESTDecorator;
import iap.rest.todolist.decorator.LlistaRESTDecorator;
import iap.rest.todolist.exceptions.ToDoListNoExisteixLlista;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.json.JSONException;
import org.json.JSONObject;
import org.restlet.data.MediaType;
import org.restlet.data.Method;
import org.restlet.data.Status;
import org.restlet.representation.Representation;
import org.restlet.representation.StringRepresentation;
import org.restlet.resource.Delete;
import org.restlet.resource.Get;
import org.restlet.resource.Options;
import org.restlet.resource.Post;
import org.restlet.resource.Put;
import org.restlet.resource.ServerResource;

public class LlistaResource extends ServerResource {

	protected ToDoList getToDoList() {
		return ((RESTToDoListApplication) this.getApplication()).getToDoList();
	}

	protected String getLlistaID() {
		return (String) getRequest().getAttributes().get("LLISTA");
	}

	protected Llista getLlista() throws ToDoListNoExisteixLlista {
		String llista = this.getLlistaID();
		Llista ll = this.getToDoList().getLlista(llista);
		if (ll == null)
			throw new ToDoListNoExisteixLlista();
		return ll;
	}

	@Get("json")
	public Representation getLlistaJSON() {
		Llista ll = null;
		try {
			ll = this.getLlista();
		} catch (ToDoListNoExisteixLlista e) {
			setStatus(Status.CLIENT_ERROR_NOT_FOUND);
			return new StringRepresentation("Llista no trobada!",
					MediaType.TEXT_PLAIN);
		}

		JSONObject json = LlistaRESTDecorator.getAsJSON(ll);

		Representation representation = new StringRepresentation(
				json.toString(), MediaType.APPLICATION_JSON);
		return representation;
	}

	@Get("xml")
	public Representation getLlistaXML() {
		Llista ll = null;
		try {
			ll = this.getLlista();
		} catch (ToDoListNoExisteixLlista e) {
			setStatus(Status.CLIENT_ERROR_NOT_FOUND);
			return new StringRepresentation("Llista no trobada!",
					MediaType.TEXT_PLAIN);
		}

		Representation representation = new StringRepresentation(
				LlistaRESTDecorator.getAsXMLDocument(ll),
				MediaType.APPLICATION_XML);
		return representation;
	}

	@Put("json")
	public Representation putLlista(Representation entity) {

		Llista ll = null;
		try {
			ll = this.getLlista();
		} catch (ToDoListNoExisteixLlista e) {
			setStatus(Status.CLIENT_ERROR_NOT_FOUND);
			return new StringRepresentation("Llista no trobada!",
					MediaType.TEXT_PLAIN);
		}

		// JSON input
		JSONObject json = null;
		String newNom = null;
		try {
			json = new JSONObject(entity.getText());
			newNom = json.getString("nom");
		} catch (JSONException e) {
			setStatus(Status.CLIENT_ERROR_UNPROCESSABLE_ENTITY);
			return new StringRepresentation("JSON format error!",
					MediaType.TEXT_PLAIN);
		} catch (IOException e) {
			setStatus(Status.CLIENT_ERROR_UNPROCESSABLE_ENTITY);
			return new StringRepresentation("JSON format error!",
					MediaType.TEXT_PLAIN);
		}

		ll.setNom(newNom);

		Representation representation = new StringRepresentation(
				LlistaRESTDecorator.getAsJSONText(ll),
				MediaType.APPLICATION_JSON);

		return representation;
	}

	@Post("json")
	public Representation postEntradaLlista(Representation entity) {

		Llista ll = null;
		try {
			ll = this.getLlista();
		} catch (ToDoListNoExisteixLlista e) {
			setStatus(Status.CLIENT_ERROR_NOT_FOUND);
			return new StringRepresentation("Llista no trobada!",
					MediaType.TEXT_PLAIN);
		}

		// JSON input
		JSONObject json = null;
		String newText = null;
		String newID = null;
		try {
			json = new JSONObject(entity.getText());
			newID = json.getString("id");
			newText = json.getString("text");
		} catch (JSONException e) {
			setStatus(Status.CLIENT_ERROR_UNPROCESSABLE_ENTITY);
			return new StringRepresentation("JSON format error!",
					MediaType.TEXT_PLAIN);
		} catch (IOException e) {
			setStatus(Status.CLIENT_ERROR_UNPROCESSABLE_ENTITY);
			return new StringRepresentation("JSON format error!",
					MediaType.TEXT_PLAIN);
		}

		EntradaLlista ell = ll.addEntrada(newID, newText);

		Representation representation = new StringRepresentation(
				EntradaLlistaRESTDecorator.getAsJSONText(ell),
				MediaType.APPLICATION_JSON);

		return representation;
	}

	@Delete
	public Representation deleteLlista() {

		Llista ll = null;
		try {
			ll = this.getLlista();
		} catch (ToDoListNoExisteixLlista e) {
			setStatus(Status.CLIENT_ERROR_NOT_FOUND);
			return new StringRepresentation("Llista no trobada!",
					MediaType.TEXT_PLAIN);
		}

		ToDoList tdl = this.getToDoList();
		tdl.removeLlista(ll.getID());

		setStatus(Status.SUCCESS_NO_CONTENT);
		return new StringRepresentation("Ok!", MediaType.TEXT_PLAIN);
	}

	@Options
	public void describe() {
		Set<Method> meths = new HashSet<Method>();
		meths.add(Method.GET);
		meths.add(Method.POST);
		meths.add(Method.PUT);
		meths.add(Method.DELETE);
		meths.add(Method.HEAD);
		meths.add(Method.OPTIONS);
		this.getResponse().setAllowedMethods(meths);
	}

}
