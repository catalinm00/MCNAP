package iap.ToDoList;

import java.util.Collection;
import java.util.Hashtable;
import java.util.Map;

public class ToDoList {

	protected Map<String, Llista> llistes = new Hashtable<String, Llista>();

	public Llista addLlista(String nom) {
		Llista ll = new Llista(nom);
		this.llistes.put(nom, ll);
		return ll;
	}

	public void removeLlista(String nom) {
		Llista ll = this.getLlista(nom);
		if (ll == null)
			return;
		ll.remove();
		this.llistes.remove(nom);
	}

	public Collection<Llista> getLlistes() {
		return this.llistes.values();
	}

	public Llista getLlista(String nom) {
		return this.llistes.get(nom);
	}

	public void remove() {
		this.llistes.clear();
	}
}
