package iap.ToDoList;

public class EntradaLlista {

	protected String llista = null;
	protected String text = null;
	protected String id;
	
	public EntradaLlista(String llista, String id, String text) {
		this.llista = llista;
		this.id = id;
		this.text = text;
	}
	
	public String getLlista() {
		return this.llista;
	}
	
	public String getID() {
		return this.id;
	}
	
	public String getText() {
		return this.text;
	}
	
	public void updateText(String text) {
		this.text = text;
	}
	
	
}
