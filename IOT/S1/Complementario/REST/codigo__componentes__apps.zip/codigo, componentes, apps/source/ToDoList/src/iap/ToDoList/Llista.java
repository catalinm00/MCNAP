package iap.ToDoList;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

public class Llista {
	
	protected String id = null;
	protected String nom = null;
	protected Map<String, EntradaLlista> elements = new Hashtable<String, EntradaLlista>();
	
	public Llista(String nom) {
		this.setID(nom.trim());
		this.setNom(nom);
	}
	
	public void setID(String id) {
		this.id = id;
	}
	
	public String getID() {
		return this.id;
	}
	
	public String getNom() {
		return this.nom;
	}
	
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public Collection<EntradaLlista> getEntrades(){
		return this.elements.values();
	}

	public EntradaLlista getEntrada(String id) {
		return this.elements.get(id);
	}

	public EntradaLlista addEntrada(String id, String text) {
		EntradaLlista ell = new EntradaLlista(this.getNom(), id, text);
		this.elements.put(id, ell);
		return ell;
	}
	
	public void removeEntrada(String id) {
		this.elements.remove(id);
	}
	
	public void remove() {
		this.elements.clear();
	}
	
}
