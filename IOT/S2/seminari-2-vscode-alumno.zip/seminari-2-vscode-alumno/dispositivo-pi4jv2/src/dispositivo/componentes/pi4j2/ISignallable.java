package dispositivo.componentes.pi4j2;

public interface ISignallable {

	public String getId();
	public ISignallable signal();

}
