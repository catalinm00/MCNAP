package dispositivotester;

import java.io.IOException;

import org.restlet.data.MediaType;
import org.restlet.representation.Representation;
import org.restlet.representation.StringRepresentation;
import org.restlet.resource.ClientResource;

import dispositivotester.utils.MySimpleLogger;

public class DispositivoTest {
	
	public static void main(String[] args) {
		
		String loggerId = "dispositivo-tester";

		// Vamos a invocar a un recurso a través de su API REST
		// ClientResource (del framework Restlet) nos asiste a generar invocaciones HTTP/REST
		//  - debemos indicarle la URI destino
		//  - podemos hacer peticiones GET, POST, PUT, DELETE, ...
		//  - debemos construir el mensaje/Payload a enviar (en operaciones POST/PUT 
		//      a través de una Representation 
		//  - como resultado, devuelve una Representation
		ClientResource cr = new ClientResource("http://localhost:8182/dispositivo/funcion/f1");
		Representation payload = new StringRepresentation("{accion:parpadear}", MediaType.TEXT_PLAIN);
		Representation result = cr.put(payload);
		
		try {
			MySimpleLogger.info(loggerId, result.getText());
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
